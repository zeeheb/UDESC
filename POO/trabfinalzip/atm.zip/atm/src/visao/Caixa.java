/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

// implementa o esqueleto do caixa, definindo saldo e metodos get e set

public class Caixa {
    double cxSaldo;
    
    public Caixa(double saldo){
        this.cxSaldo = saldo;
    }
    
    void setCxSaldo(double saldo) {
        this.cxSaldo = saldo;
    }
    
    double getCxSaldo() {
        return cxSaldo;
    }
}
